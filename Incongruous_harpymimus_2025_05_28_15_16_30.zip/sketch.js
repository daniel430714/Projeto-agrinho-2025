let sementes = []; // Armazena as sementes plantadas

function setup() {
  createCanvas(600, 400);
  background(200, 220, 255); // Céu azul claro
  textSize(16);
  fill(50);
  text("Clique no solo para plantar uma semente!", 150, 30);
}

function draw() {
  // Desenha o solo
  fill(90, 200, 80); 
  rect(0, 300, width, 100);

  // Desenha todas as sementes plantadas
  for (let i = 0; i < sementes.length; i++) {
    sementes[i].grow(); // Atualiza o crescimento da planta
    sementes[i].display(); // Exibe a planta
  }
}

function mousePressed() {
  // Plante uma nova semente onde o usuário clicar
  let semente = new Semente(mouseX, mouseY);
  sementes.push(semente);
}

class Semente {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 5; // Tamanho inicial da semente
    this.growth = 0; // Estágio de crescimento (0 a 1)
  }

  grow() {
    if (this.growth < 1) {
      this.growth += 0.01; // Crescimento gradual
    }
  }

  display() {
    // Cor e tamanho com base no estágio de crescimento
    fill(34, 139, 34); // Cor verde para a planta
    ellipse(this.x, this.y - 10 - this.growth * 100, this.size, this.size + this.growth * 50);
  }
}
